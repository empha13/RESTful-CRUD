<?php
class Constants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=localhost;dbname=musicdb";
    public static $MYSQL_USERNAME = "eanderson";
    public static $MYSQL_PASSWORD = "mysql";
}
